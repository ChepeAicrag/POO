public class Persona
{
  private String nombre;
  public Persona(String nombre){
    setnombre(nombre);
    }
  public void setnombre(String nombre){
    this.nombre=nombre;
    }
  public String getnombre(){
    return nombre;
    } 
  public void prender(Computadora c){
    if(c.getestado()=='a'){
    c.setestado('p');
    }
    else{
    c.setestado(c.getestado());
    }
  }
  public void suspender(Computadora c){
    if(c.getestado()=='p'){
     c.setestado('s');
    }
    else{
    c.setestado(c.getestado());
    }
    }
  public void apagar(Computadora c){
    if(c.getestado()=='p'){
    c.setestado('a');
    }
    else{
    c.setestado(c.getestado());
    }
    }
}
