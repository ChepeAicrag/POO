public class Computadora
{
 private char estado;   
 public Computadora(char estado){
 setestado(estado);
 }
 public char getestado(){
    return estado;
    }
 public void setestado(char estado){
    this.estado=estado;
    }   
}
