public class Persona
{
 private String nombre;
 public Persona(String nombre){
    setnombre(nombre);
    }
 public void setnombre(String nombre){
    this.nombre=nombre;
    }   
 public String getnombre(){
    return nombre;
    }   
 public void apagarencender(Television t){
    t.setestado(!t.getestado());
    }
 public void subircanal(Television t){
    if(t.getestado()==true){ 
    if(t.getncan()<t.getcanalmax()){
       t.setncan(t.getncan()+1);
    }
    else{
    t.setncan(1);
    }
    }
    }  
 public void bajacanal(Television t){
    if(t.getestado()==true){ 
      if(t.getncan()>1){
       t.setncan(t.getncan()-1);
       }
      else{
         t.setncan(1);
       }
     }
    }   
 public void subirvol(Television t){
    if(t.getestado()==true){
     if(t.getvol()<t.getvolmax()){
      t.setvol(t.getvol()+1);
       }
     else{
     t.setvol(t.getvol());
     }
    }
    }
 public void bajarvol(Television t){
    if(t.getestado()==true){
     if(t.getvol()>0){
       t.setvol(t.getvol()-1);
       }
     else{
       t.setvol(0);
       }
    }
    }
}
