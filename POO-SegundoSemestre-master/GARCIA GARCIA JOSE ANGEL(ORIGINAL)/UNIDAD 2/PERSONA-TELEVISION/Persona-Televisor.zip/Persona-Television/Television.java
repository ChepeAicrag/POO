public class Television
{
    private boolean estado;
    private int vol,volmax,ncan=1,canalmax;
    public Television(boolean estado, int canalmax, int volmax){
    setestado(estado);
    setcanalmax(canalmax);
    setvolmax(volmax);
    }
    public void setestado(boolean estado){
    this.estado=estado;
    }
    public boolean getestado(){
    return estado;
    }
    public void setvol(int vol){
    this.vol=vol;
    }
    public int getvol(){
    return vol;
    }
    public void setncan(int ncan){    
    this.ncan=ncan;
    }
    public int getncan(){
    return ncan;
    }
    public void setcanalmax(int canalmax){
    if(canalmax>0){    
    this.canalmax=canalmax;
    }
    else{
    setcanalmax(1);
    }
    }
    public int getcanalmax(){
    return canalmax;
    }
    public void setvolmax(int volmax){
    if(volmax>0){    
    this.volmax=volmax;
    }
    else{
    setvolmax(1);
    }
    }
    public int getvolmax(){
    return volmax;
    }
}
