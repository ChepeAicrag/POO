public class Contacto
{
   private int numtel;
   public Contacto(int numtel){
    setnumtel(numtel);
    }
   public void setnumtel(int numtel){
    if(numtel>0){   
    this.numtel=numtel;
    }
    } 
   public int getnum(){
    return numtel;
    } 
}
