public class Persona
{
    private String nombre;
    public Persona(String nombre){
    setnombre(nombre);
    }
    public void setnombre(String nom){
    nombre=nom;
    }
    public String getnombre(){
    return nombre;
    }
    public void prender(Celular c){
    if(c.getestado()=='a'){
       c.setestado('p');
    }    
    }
    public void apagar(Celular c){
    if(c.getestado()=='p'){
       c.setestado('a');
    }
    }
    public void reiniciar(Celular c){
    if(c.getestado()=='p'){
       c.setestado('r');
    }
    }
    public void llamar(Celular c, Contacto co){
    if(c.getestado()=='p' && co.getnum()!=0){
      c.setestado('y');
     }
    }
    public void colgar(Celular c){
    if(c.getestado()=='y'){
       c.setestado('p');
    }
    }
}
