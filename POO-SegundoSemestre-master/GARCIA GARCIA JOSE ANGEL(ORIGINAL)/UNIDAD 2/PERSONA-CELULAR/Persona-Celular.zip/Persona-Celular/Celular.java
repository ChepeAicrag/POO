public class Celular
{
   private char estado;
   public Celular(char estado){
    setestado(estado);
    }
   public void setestado(char estado){
    this.estado=estado;
    } 
   public char getestado(){
    return estado;
    } 
}
