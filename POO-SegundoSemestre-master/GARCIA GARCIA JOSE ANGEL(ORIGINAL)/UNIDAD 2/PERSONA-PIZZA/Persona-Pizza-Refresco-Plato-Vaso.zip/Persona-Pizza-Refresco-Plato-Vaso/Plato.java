public class Plato
{
 private boolean estado;
 public Plato(boolean estado){
    setestado(estado);
    }
 public void setestado(boolean estado){
    this.estado=estado;
    } 
 public boolean getestado(){
    return estado;
    }   
}