public class Refresco
{
    private int nvasos;
    public Refresco(int nvasos){
    setnvasos(nvasos);
    }
    public void setnvasos(int nvasos){
    if(nvasos>0){    
      this.nvasos=nvasos;
      }
     else{
        this.nvasos=0;
        }
    }
    public int getnvasos(){
    return nvasos;
    }
}
