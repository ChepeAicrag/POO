public class Persona
{
 private String nombre;
 public Persona(String nombre){
    setnombre(nombre);
    }
 public void setnombre(String nombre){
    this.nombre=nombre; 
    }   
 public String getnombre(){
    return nombre;
    }
 public void servirr(Refresco r, Vaso v){
    if((r.getnvasos()>0) && (v.getestado()==false)){
       r.setnvasos(r.getnvasos()-1);
       v.setestado(true);
    }
    else{
    r.setnvasos(r.getnvasos());
    v.setestado(v.getestado());
    }
    }
 public void servirp(Pizza p, Plato pl){
    if((p.getnreb()>0) && (pl.getestado()==false)){
       p.setnreb(p.getnreb()-1);
       pl.setestado(true);
    }
    else{
     p.setnreb(p.getnreb());
     pl.setestado(pl.getestado());
    }
    }   
 public void comer(Plato pl){
    pl.setestado(!pl.getestado());
    }   
 public void tomar(Vaso v){
    v.setestado(!v.getestado());
    }   
}
