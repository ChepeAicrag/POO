public class Pizza
{
  private int nreb;
  public Pizza(int nreb){
    setnreb(nreb);
    }
  public void setnreb(int nreb){
    if(nreb>0){  
    this.nreb=nreb;
    }
    else{
    this.nreb=0;
    }
    }  
  public int getnreb(){
    return nreb;
    }  
}
